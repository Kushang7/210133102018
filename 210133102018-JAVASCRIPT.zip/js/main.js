
            function alert2()
            {
                alert('aya click na karsso')  
            }       
            function confirm2()
            {
                confirm('pakku')  
            }       
            function prompt2()
            {
                prompt('pakkku ne')  
            }       
            function background()
            {
                document.body.style.backgroundColor = document.getElementById("C1").value;

            }
            function div()
            {
                document.getElementById("d1").style.backgroundColor = document.getElementById("C2").value;
                
            }